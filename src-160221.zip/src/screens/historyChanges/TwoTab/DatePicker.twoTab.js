import React, { useState} from 'react';

import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';




const useStyles = makeStyles((theme) => ({
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(4),
    width: 200,
  },
}));

const initional = () => {
    let newDate = new Date();//.toISOString().split('T')[0];
    newDate.setDate(newDate.getDate() - 7);
    return newDate.toISOString().split('T')[0];
}


///////////////////////////////////////////////


const DatePickers =({setDataStart}) => {
  const [Data, setData] = useState(initional);
  const classes = useStyles();

  // console.log('DatePickers init');
  

  const setDate = (e) => {
    const eT = e.target.value.toString();
    setData(eT);
    setDataStart(new Date(eT).toISOString());
  }

  return (
    <form className={classes.container} noValidate>
      <TextField
        id="dateStart"
        label="Дата начала диапозона"
        type="date"
        defaultValue={Data}
        className={classes.textField}
        InputLabelProps={{
          shrink: true,
        }}
        onBlur={setDate}
      />
    </form>
  );
}


export default DatePickers;