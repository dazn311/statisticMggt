import ORGANIZATIONS_DATA from './adminPanelTrest.data';
import AdminActionTypes, {FetchData, FetchDataStaticPage} from './adminPanelTrest.types';
// import { fetchDataUsersOnline } from './adminPanelTrest.actions';
  
const INITIAL_STATE = {
    countUsers: ORGANIZATIONS_DATA.countUsers,
    countOGH: ORGANIZATIONS_DATA.countOGH,
    amountNewOGH: ORGANIZATIONS_DATA.amountNewOGH,
    amountOGHtoDay: ORGANIZATIONS_DATA.amountOGHtoDay,
    amountOGHtoWeek: ORGANIZATIONS_DATA.amountOGHtoWeek,
    amountOGHtoTreeDays: ORGANIZATIONS_DATA.amountOGHtoTreeDays,
    countEventGraph: ORGANIZATIONS_DATA.countEventGraph,
    countUsersGraph: ORGANIZATIONS_DATA.countUsersGraph,
    messagesEventPoints: ORGANIZATIONS_DATA.messagesEventPoints,
    statusEnumEventPoint: ORGANIZATIONS_DATA.statusEnumEventPoint,
    eventPoints: ORGANIZATIONS_DATA.eventPoints,
    eventShortPoints: ORGANIZATIONS_DATA.eventShortPoints, //for events page
    fetchDataForEventShortPoints: ORGANIZATIONS_DATA.fetchDataForEventShortPoints, //fetch for events page
    amountEventGraph: ORGANIZATIONS_DATA.amountEventGraph,
    amountEndEventGraph: ORGANIZATIONS_DATA.amountEndEventGraph,
    statusEnumEventPointColor: ORGANIZATIONS_DATA.statusEnumEventPointColor,
    newEventsGraphOfStaticPage: ORGANIZATIONS_DATA.newEventsGraphOfStaticPage, // for GraphOfStaticPage
    endEventsGraphOfStaticPage: ORGANIZATIONS_DATA.endEventsGraphOfStaticPage,// for GraphOfStaticPage
    usersOnlineGraphOfStaticPage: ORGANIZATIONS_DATA.usersOnlineGraphOfStaticPage,// for GraphOfStaticPage
    newMessageGraphOfStaticPage: ORGANIZATIONS_DATA.newMessageGraphOfStaticPage,// for GraphOfStaticPage
    currentPointId: 1,
    isFetchingUserOnline: false,
    errorMessage: undefined,
};

const adminPandelReducer = (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case AdminActionTypes.SET_CURRENT_POINT:
            return {...state, currentPointId: action.payload};

        case FetchData.GET_USERS_ONLINE_START:
            return {...state, isFetchingUserOnline: true};

        case FetchData.GET_USERS_ONLINE_SUCCESS:
            return {...state, countUsersGraph: action.payload, isFetchingUserOnline: false};

        case FetchData.GET_USERS_ONLINE_FAILURE:
            return {...state, errorMessage: action.payload, isFetchingUserOnline: false};

        case FetchData.GET_EVENTS_POINT_START: // for botton tab
                return {...state, eventShortPoints: action.payload}; 
        
        case FetchData.FETCH_EVENT_TYPE_OF_DATE_FOR_STATISTIC_PAGE: // for events page
                return {...state, eventShortPoints: action.payload};

        case FetchData.DATA_START_FOR_FETCH_EVENT_TYPE_OF_DATE_FOR_STATISTIC_PAGE: // DATA for events page
                const newDate = {...state.fetchDataForEventShortPoints, startDate: action.payload}
                return {...state, fetchDataForEventShortPoints: newDate}; 
        
        case FetchData.DATA_END_FOR_FETCH_EVENT_TYPE_OF_DATE_FOR_STATISTIC_PAGE: // DATA for events page
                const newEndDate = {...state.fetchDataForEventShortPoints, endDate: action.payload}
                return {...state, fetchDataForEventShortPoints: newEndDate}; 

        case FetchData.GET_NEW_EVENTS_FOR_GRAPHIC_START:
                return {...state, amountEventGraph: action.payload};

        case FetchData.GET_END_EVENTS_FOR_GRAPHIC_START:
                return {...state, amountEndEventGraph: action.payload};

        case FetchData.FETCH_COUNT_OGH_FOR_DASHBOARD:
                return {...state, countOGH: action.payload};

        case FetchData.FETCH_AMOUNT_OGH_TO_DAY_FOR_DASHBOARD:
                return {...state, amountOGHtoDay: action.payload};

        case FetchData.FETCH_AMOUNT_OGH_TO_TREE_DAYS_FOR_DASHBOARD:
            return {...state, amountOGHtoTreeDays: action.payload};

        case FetchData.FETCH_AMOUNT_OGH_TO_WEEK_FOR_DASHBOARD:
                return {...state, amountOGHtoWeek: action.payload};
        
        case FetchDataStaticPage.FETCH_NEW_EVENT_TO_GRAPHIC_TO_STATISTIC_PAGE:
                return {...state, newEventsGraphOfStaticPage: action.payload};
                
        case FetchDataStaticPage.FETCH_END_EVENT_TO_GRAPHIC_TO_STATISTIC_PAGE:
                return {...state, endEventsGraphOfStaticPage: action.payload};
       
        case FetchDataStaticPage.FETCH_USERS_ONLINE_TO_GRAPHIC_TO_STATISTIC_PAGE:
                return {...state, usersOnlineGraphOfStaticPage: action.payload};

        case FetchDataStaticPage.FETCH_NEW_MESSAGE_TO_GRAPHIC_TO_STATISTIC_PAGE:
                return {...state, newMessageGraphOfStaticPage: action.payload};

        default:
            return state;
    }
}


export default adminPandelReducer;