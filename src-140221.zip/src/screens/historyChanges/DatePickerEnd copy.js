import React, { useState, useEffect} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';

const useStyles = makeStyles((theme) => ({
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(4),
    width: 200,
  },
}));

export default function DatePickers({changeDate}) {
  const [Data, setData] = useState("2021-02-11"); //'2021-02-11T00-00-00.000Z'
  const classes = useStyles();

  useEffect(() => {
    const newDate = new Date().toISOString().split('T')[0];
    setData(newDate);
    // console.log('newDate',newDate);
  }, []);

  const setDate = (e) => {
    const eT = e.target.value.toString();
    setData(eT);
    changeDate(eT);
    // console.log(e.target.value); // 2021-02-11
  }

  return (
    <form className={classes.container} noValidate>
      <TextField
        id="date"
        label="Дата конца диапозона"
        type="date"
        defaultValue={Data}
        // value={Data}
        className={classes.textField}
        InputLabelProps={{
          shrink: true,
        }}
        onBlur={setDate}
      />
    </form>
  );
}
