import ORGANIZATIONS_DATA from './adminPanelTrest.data';
import AdminActionTypes, {FetchData} from './adminPanelTrest.types';
// import { fetchDataUsersOnline } from './adminPanelTrest.actions';
  
const INITIAL_STATE = {
    countUsers: ORGANIZATIONS_DATA.countUsers,
    countOGH: ORGANIZATIONS_DATA.countOGH,
    amountNewOGH: ORGANIZATIONS_DATA.amountNewOGH,
    amountOGHtoDay: ORGANIZATIONS_DATA.amountOGHtoDay,
    amountOGHtoWeek: ORGANIZATIONS_DATA.amountOGHtoWeek,
    amountOGHtoTreeDays: ORGANIZATIONS_DATA.amountOGHtoTreeDays,
    countEventGraph: ORGANIZATIONS_DATA.countEventGraph,
    countUsersGraph: ORGANIZATIONS_DATA.countUsersGraph,
    messagesEventPoints: ORGANIZATIONS_DATA.messagesEventPoints,
    statusEnumEventPoint: ORGANIZATIONS_DATA.statusEnumEventPoint,
    eventPoints: ORGANIZATIONS_DATA.eventPoints,
    eventShortPoints: ORGANIZATIONS_DATA.eventShortPoints, //for events page
    fetchDataForEventShortPoints: ORGANIZATIONS_DATA.fetchDataForEventShortPoints, //fetch for events page
    amountEventGraph: ORGANIZATIONS_DATA.amountEventGraph,
    amountEndEventGraph: ORGANIZATIONS_DATA.amountEndEventGraph,
    statusEnumEventPointColor: ORGANIZATIONS_DATA.statusEnumEventPointColor,
    currentPointId: 1,
    isFetchingUserOnline: false,
    errorMessage: undefined,
};

const adminPandelReducer = (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case AdminActionTypes.SET_CURRENT_POINT:
            return {...state, currentPointId: action.payload};

        case FetchData.GET_USERS_ONLINE_START:
            return {...state, isFetchingUserOnline: true};

        case FetchData.GET_USERS_ONLINE_SUCCESS:
            return {...state, countUsersGraph: action.payload, isFetchingUserOnline: false};

        case FetchData.GET_USERS_ONLINE_FAILURE:
            return {...state, errorMessage: action.payload, isFetchingUserOnline: false};

        case FetchData.GET_EVENTS_POINT_START: // for botton tab
                return {...state, eventShortPoints: action.payload}; 
        
        case FetchData.FETCH_EVENT_TYPE_OF_DATE_FOR_STATISTIC_PAGE: // for events page
                return {...state, eventShortPoints: action.payload};

        case FetchData.DATA_START_FOR_FETCH_EVENT_TYPE_OF_DATE_FOR_STATISTIC_PAGE: // DATA for events page
                const newDate = {...state.fetchDataForEventShortPoints, startDate: action.payload}
                return {...state, fetchDataForEventShortPoints: newDate}; 
        
        case FetchData.DATA_END_FOR_FETCH_EVENT_TYPE_OF_DATE_FOR_STATISTIC_PAGE: // DATA for events page
                const newEndDate = {...state.fetchDataForEventShortPoints, endDate: action.payload}
                return {...state, fetchDataForEventShortPoints: newEndDate}; 

        case FetchData.GET_NEW_EVENTS_FOR_GRAPHIC_START:
                return {...state, amountEventGraph: action.payload};

        case FetchData.GET_END_EVENTS_FOR_GRAPHIC_START:
                return {...state, amountEndEventGraph: action.payload};

        case FetchData.FETCH_COUNT_OGH_FOR_DASHBOARD:
                return {...state, countOGH: action.payload};

        case FetchData.FETCH_AMOUNT_OGH_TO_DAY_FOR_DASHBOARD:
                return {...state, amountOGHtoDay: action.payload};

        case FetchData.FETCH_AMOUNT_OGH_TO_TREE_DAYS_FOR_DASHBOARD:
            return {...state, amountOGHtoTreeDays: action.payload};

        case FetchData.FETCH_AMOUNT_OGH_TO_WEEK_FOR_DASHBOARD:
                return {...state, amountOGHtoWeek: action.payload};

        default:
            return state;
    }
}


export default adminPandelReducer;