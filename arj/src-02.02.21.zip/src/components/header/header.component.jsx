import React from "react";
import {
    Link
  } from "react-router-dom";

import { connect } from 'react-redux';

import { ReactComponent as Logo } from "../../logo_header.svg";

import { setCurrentUser } from '../../store/user/user.actions';

import { selectCurrentUser } from '../../store/user/user.selectors';

import './header.styles.scss';



const Header = ({ currentUser, logOutUser}) => {

    const name = currentUser ? currentUser.login : 'guest';
    const labelExitButton = currentUser ? 'Выход' : 'Логин';
    let toLink = '/users';

    const logOut = () => {
        if ( !currentUser ) {toLink = '/users' }
        logOutUser();
    };

    return (
        <div className="Admin-header">
        
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                
                    <Logo /> 
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav">
                        <li className="nav-item active">
                        <Link className="nav-link" to="/">Главная</Link>
                            
                        </li>
                        <li className="nav-item">
                        <Link className="nav-link" to="/adminpanel">События</Link>
                            
                        </li>
                        <li className="nav-item">
                            <div style={{width:'800px', margin:'auto'}}></div>    
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/adminpanel" style={{color: 'chocolate'}}>Вы зашли как <b>{name}</b></Link>
                             
                        </li>
                        <li className="nav-item">
                        <Link 
                        className="nav-link" 
                        onClick={logOut}
                        to={toLink} 
                        style={{color: 'blue'}}>{labelExitButton}</Link>
                           
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    )
    
}
 

const mapDispatchToProps = dispatch => ({
    logOutUser: () => dispatch(setCurrentUser(null))
  });

  const mapStateToProps = (state) => ({
      currentUser: selectCurrentUser(state),
  });

  export default connect(mapStateToProps, mapDispatchToProps)(Header);