import {store, persistor} from './store';
export  {store};
export  {persistor};

export default store