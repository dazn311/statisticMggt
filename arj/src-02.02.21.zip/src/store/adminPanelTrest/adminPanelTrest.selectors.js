import { createSelector } from 'reselect';

export const selectPoints = state => state.adminPanel;

 

export const selectCurrentPointId = createSelector(
    [selectPoints],
    adminPanel => adminPanel.currentPointId
)

export const allPoints = createSelector(
    [selectPoints],
    adminPanel => adminPanel.points.items
)
export const allObjects = createSelector(
    [selectPoints],
    adminPanel => adminPanel.objects
)
export const allOrganisations = createSelector(
    [selectPoints],
    adminPanel => adminPanel.organizations
)
export const countUsers = createSelector(
    [selectPoints],
    adminPanel => adminPanel.countUsers
)
export const countOGH = createSelector(
    [selectPoints],
    adminPanel => adminPanel.countOGH
)
export const countUsersGraph = createSelector(
    [selectPoints],
    adminPanel => adminPanel.countUsersGraph
)
export const countEventGraph = createSelector(
    [selectPoints],
    adminPanel => adminPanel.countEventGraph
)
export const messagesEventPoint = createSelector( 
    [selectPoints],
    adminPanel => adminPanel.messagesEventPoints
)
export const eventPoints = createSelector( 
    [selectPoints],
    adminPanel => adminPanel.eventPoints
)
export const statusEventPoint = createSelector( 
    [selectPoints],
    adminPanel => adminPanel.statusEnumEventPoint
)
 
// export const setSelectPoints = createSelector(
//     [selectPoints],
//     adminPanel => adminPanel.currentPointId = 
//   );
  
  