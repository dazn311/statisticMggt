import ORGANIZATIONS_DATA from './adminPanelTrest.data';
import AdminActionTypes from './adminPanelTrest.types'
 
const INITIAL_STATE = {
    points: ORGANIZATIONS_DATA.points,
    organizations: ORGANIZATIONS_DATA.organizations,
    objects: ORGANIZATIONS_DATA.objects,
    countUsers: ORGANIZATIONS_DATA.countUsers,
    countOGH: ORGANIZATIONS_DATA.countOGH,
    countEventGraph: ORGANIZATIONS_DATA.countEventGraph,
    countUsersGraph: ORGANIZATIONS_DATA.countUsersGraph,
    messagesEventPoints: ORGANIZATIONS_DATA.messagesEventPoints,
    statusEnumEventPoint: ORGANIZATIONS_DATA.statusEnumEventPoint,
    eventPoints: ORGANIZATIONS_DATA.eventPoints,
    currentPointId: 1 
};

const adminPandelReducer = (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case AdminActionTypes.SET_CURRENT_POINT:
            return {...state, currentPointId: action.payload};
        default:
            return state;
    }
}

export default adminPandelReducer;