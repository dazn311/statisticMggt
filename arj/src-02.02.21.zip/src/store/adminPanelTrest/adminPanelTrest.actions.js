import AdminActionTypes from './adminPanelTrest.types';

export const setCurrentPoint = (item) => ({
  type: AdminActionTypes.SET_CURRENT_POINT,
  payload: item
});

