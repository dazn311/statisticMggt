const AdminActionTypes = {
    SET_CURRENT_POINT: 'SET_CURRENT_POINT',
  };
  
  export default AdminActionTypes;
  