import { createSelector } from 'reselect';

const getSelectPoints = (state) => state.adminPanel;


export const selectCurrentPointId = createSelector(
    [getSelectPoints],
    adminPanel => adminPanel.currentPointId
)

export const selectAllPoints = createSelector(
    [getSelectPoints],
    adminPanel => adminPanel.points.items
)
export const selectAllObjects = createSelector(
    [getSelectPoints],
    adminPanel => adminPanel.objects
)
export const selectAllOrganisations = createSelector(
    [getSelectPoints],
    adminPanel => adminPanel.organizations
)
export const selectCountUsers = createSelector(
    [getSelectPoints],
    adminPanel => adminPanel.countUsers
)
export const selectCountOGH = createSelector(
    [getSelectPoints],
    adminPanel => adminPanel.countOGH
) 
export const selectCountUsersGraph = createSelector(
    [getSelectPoints],
    adminPanel => adminPanel.countUsersGraph
)
export const selectCountEventGraph = createSelector(
    [getSelectPoints],
    adminPanel => adminPanel.countEventGraph
)
export const selectMessagesEventPoint = createSelector( 
    [getSelectPoints],
    adminPanel => adminPanel.messagesEventPoints
)
export const selectEventPoints = createSelector( 
    [getSelectPoints],
    adminPanel => adminPanel.eventPoints
)

export const selectStatusEventPoint = createSelector( 
    [getSelectPoints],
    adminPanel => adminPanel.statusEnumEventPoint
)
export const selectIsFetchingUserOnline = createSelector( 
    getSelectPoints,
    adminPanel => adminPanel.isFetchingUserOnline
)

export const selectEventShortPoints = createSelector( 
    getSelectPoints,
    adminPanel => adminPanel.eventShortPoints
)
export const selectAmountEventGraph = createSelector( 
    getSelectPoints,
    adminPanel => adminPanel.amountEventGraph
) 
 
// export const setSelectPoints = createSelector(
//     [getSelectPoints],
//     adminPanel => adminPanel.currentPointId = 
//   );
  
  