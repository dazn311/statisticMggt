import AdminActionTypes,{ FetchData } from './adminPanelTrest.types';

export const setCurrentPoint = (item) => ({
  type: AdminActionTypes.SET_CURRENT_POINT,
  payload: item
});

export const putDataUsersOnlineStart = () => ({
  type: FetchData.GET_USERS_ONLINE_START
});
export const putDataUsersOnlineError = (errorMessage) => ({
  type: FetchData.GET_USERS_ONLINE_FAILURE,
  payload: errorMessage
});

export const putDataUsersOnline = (items) => ({
  type: FetchData.GET_USERS_ONLINE_SUCCESS,
  payload: items 
});

export const putEventsPointShort = (items) => ({
  type: FetchData.GET_EVENTS_POINT_START,
  payload: items 
});

export const putNewEventsGraphic = (items) => ({
  type: FetchData.GET_NEW_EVENTS_FOR_GRAPHIC_START,
  payload: items 
});

export const putEndEventsGraphic = (items) => ({
  type: FetchData.GET_END_EVENTS_FOR_GRAPHIC_START, //amountEndEventGraph
  payload: items 
});
 

async function postData(url = '', data = {}) {
  // Default options are marked with *
  const response = await fetch(url, {
    method: 'POST', // *GET, POST, PUT, DELETE, etc.
    mode: 'cors', // no-cors, *cors, same-origin
    cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached
    credentials: 'same-origin', // include, *same-origin, omit
    headers: {
      'Content-Type': 'application/json'
      // 'Content-Type': 'application/x-www-form-urlencoded',
    },
    redirect: 'follow', // manual, *follow, error
    referrerPolicy: 'no-referrer', // no-referrer, *client
    body: JSON.stringify(data) // body data type must match "Content-Type" header
  });
  return await response.json(); // parses JSON response into native JavaScript objects
}

export const fetchDataUsersOnlineAsync = () => {
  return (dispatch) => {
    dispatch(putDataUsersOnlineStart());
    
    postData('http://176.53.160.74:1000/query/users/online', {limit:10})
      .then((users) => {
        // let chartData = users.data.chartData.slice(7,17);
        // console.log(chartData); // JSON data parsed by `response.json()` call
        dispatch(putDataUsersOnline(users));
      })
      .catch(error => dispatch(putDataUsersOnlineError(error.message)));
  };
};

export const fetchEventsPointShortAsync = () => {
  return (dispatch) => {
    postData('http://176.53.160.74:1000/query/events/last/short', {limit:10})
      .then((eventss) => {
        dispatch(putEventsPointShort(eventss));
      })
      .catch(error => dispatch(putDataUsersOnlineError(error.message)));
  };
};

export const fetchAmountEventsForGraphicAsync = () => {
  return (dispatch) => {
    postData('http://176.53.160.74:1000/query/events/amount', {type: 'new_rec'})
      .then((eventss) => {
        // console.log('eventss',eventss);
        dispatch(putNewEventsGraphic(eventss));
      })
      .catch(error => dispatch(putDataUsersOnlineError(error.message)));
  };
};
export const fetchAmountEndEventsForGraphicAsync = () => {
  return (dispatch) => {
    postData('http://176.53.160.74:1000/query/events/amount', {type: 'done_rec'})
      .then((eventss) => {
        // console.log('eventss',eventss);
        dispatch(putEndEventsGraphic(eventss));
      })
      .catch(error => dispatch(putDataUsersOnlineError(error.message)));
  };
};




