import ORGANIZATIONS_DATA from './adminPanelTrest.data';
import AdminActionTypes, {FetchData} from './adminPanelTrest.types';
// import { fetchDataUsersOnline } from './adminPanelTrest.actions';
  
const INITIAL_STATE = {
    countUsers: ORGANIZATIONS_DATA.countUsers,
    countOGH: ORGANIZATIONS_DATA.countOGH,
    countEventGraph: ORGANIZATIONS_DATA.countEventGraph,
    countUsersGraph: ORGANIZATIONS_DATA.countUsersGraph,
    messagesEventPoints: ORGANIZATIONS_DATA.messagesEventPoints,
    statusEnumEventPoint: ORGANIZATIONS_DATA.statusEnumEventPoint,
    eventPoints: ORGANIZATIONS_DATA.eventPoints,
    eventShortPoints: ORGANIZATIONS_DATA.eventShortPoints,
    amountEventGraph: ORGANIZATIONS_DATA.amountEventGraph,
    amountEndEventGraph: ORGANIZATIONS_DATA.amountEndEventGraph,
    currentPointId: 1,
    isFetchingUserOnline: false,
    errorMessage: undefined,
};

const adminPandelReducer = (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case AdminActionTypes.SET_CURRENT_POINT:
            return {...state, currentPointId: action.payload};

        case FetchData.GET_USERS_ONLINE_START:
            return {...state, isFetchingUserOnline: true};

        case FetchData.GET_USERS_ONLINE_SUCCESS:
            return {...state, countUsersGraph: action.payload, isFetchingUserOnline: false};

        case FetchData.GET_USERS_ONLINE_FAILURE:
            return {...state, errorMessage: action.payload, isFetchingUserOnline: false};

        case FetchData.GET_EVENTS_POINT_START:
                return {...state, eventShortPoints: action.payload}; 

        case FetchData.GET_NEW_EVENTS_FOR_GRAPHIC_START:
                return {...state, amountEventGraph: action.payload};
        case FetchData.GET_END_EVENTS_FOR_GRAPHIC_START:
                return {...state, amountEventGraph: action.payload};
        default:
            return state;
    }
}

export default adminPandelReducer;