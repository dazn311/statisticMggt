import React from 'react';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
// import Link from '@material-ui/core/Link';
// import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Title from './Title';

// function preventDefault(event) {
//   event.preventDefault();
// }

// const useStyles = makeStyles({
//   depositContext: {
//     flex: 1,
//   },
// });

const Deposits = () => {
  // const classes = useStyles();
  return (
    <React.Fragment>
      <Title>Новые ОГХ</Title>
      <hr color="blue" style={{width: '100%',opacity: 0.5, marginTop: 0, marginBottom: 0}}/>
      <Typography component="p" variant="h6">
        22
      </Typography>
      <Typography component="p"  >
      сегодня
      </Typography>
      <hr color="gray" style={{width: '100%',opacity: 0.5, marginTop: 0, marginBottom: 0}}/>
      <Typography component="p" variant="h6">
        42
      </Typography>
      <Typography component="p"  >
      за три дня
      </Typography>
      <hr color="gray" style={{width: '100%',opacity: 0.5, marginTop: 0, marginBottom: '4px'}}/>
      <Typography component="p" variant="h6">
        108
      </Typography>
      <Typography component="p"  >
      за неделю
      </Typography>
      <div>
        {/* <Link color="primary" href="#" onClick={preventDefault}>
          Смотреть подробно
        </Link> */}
      </div>
    </React.Fragment>
  );
}

const mapStateToProps = createStructuredSelector ({
  // eventShortPoints: selectEventShortPoints,
  // countUsersGraph: selectCountUsersGraph,
  // statusEventPoint: selectStatusEventPoint,
});


export default connect(mapStateToProps)(Deposits);