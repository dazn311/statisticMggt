import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';

import { selectCountUsersGraph, selectIsFetchingUserOnline, selectAmountEventGraph } from '../../store/adminPanelTrest/adminPanelTrest.selectors'; 
import { fetchDataUsersOnlineAsync } from '../../store/adminPanelTrest/adminPanelTrest.actions'; 
import RefreshIcon from '@material-ui/icons/Refresh';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend
} from 'recharts';

let data = [
  {
    name: '08:00', Events: null, Users: null, Close: null, amt: 3,
  },
  {
    name: '09:00', Events: null, Users: null, Close: null, amt: 3,
  },
  {
    name: '10:00', Events: null, Users: null, Close: null, amt: 4,
  },
  {
    name: '11:00', Events: null, Users: null, Close: null, amt: 40,
  },
  {
    name: '12:00', Events: null, Users: null, Close: null, amt: 14,
  },{
    name: '13:00', Events: null, Users: null, Close: null, amt: 14,
  },
  {
    name: '14:00', Events: null, Users: null, Close: null, amt: 21,
  },
  {
    name: '15:00', Events: null, Users: null, Close: null, amt: 21,
  },
  {
    name: '16:00', Events: null, Users: null, Close: null, amt: 32,
  },
  {
    name: '17:00', Events: null, Users: null, Close: null, amt: 30,
  },
  {
    name: '18:00', Events: null, Users: null, Close: null, amt: 0,
  },
];

class LineChartWithXAxisPading extends PureComponent {
//   static jsfiddleUrl = 'https://jsfiddle.net/alidingling/g03265a4/';
 


render() {
  const {countUsersGraph, fetchDataUsersOnline, isFetchingUserOnline, selectAmountEvent} = this.props;
  const MinTime = 8;
  // const MaxTime = 18;
    //countUsersGraph.data.chartData.slice(7,17);
    const currentDate = new Date();
    const cD = currentDate.toString().split(' ')[4].split(':')[0];
    // const dl = MaxTime - dd
    const dl2 = +cD - MinTime +1;
    let usersCount = 0;
    let eventsAmount = 0;
    const usersLine = countUsersGraph.data.chartData.slice(-dl2);
    const eventsLine = selectAmountEvent.data.chartData.slice(-dl2);

    usersLine.forEach((el,index) => {
      const newObj = {...data[index], Users: el};
      usersCount = el;
      data[index] = newObj;
       
    }); 
    eventsLine.forEach((el,index) => {
      const newObj = {...data[index], Events: el};
      eventsAmount = el;
      data[index] = newObj;
       
    }); 

    // console.log(window.innerWidth);
    const styleBtnUpdateUsersGraphic = isFetchingUserOnline ? {position: 'absolute', bottom: '15px', right: '10px', cursor:'pointer', transition: 'transform 0.2s'}
    :{position: 'absolute', bottom: '15px', right: '10px', cursor:'pointer', transform: 'rotate(-45deg)', color:'red'};
    
    const styleLblUsersGraphic = !isFetchingUserOnline ? {position: 'absolute', top: '45px', right: '10px', color:'#483d93'}
    : {position: 'absolute', top: '45px', right: '10px', color:'#ccc'};

    const styleLblUsersGraphic2 = !isFetchingUserOnline ? {position: 'absolute', top: '20px', right: '10px', color:'rgb(114 153 143)'}
    : {position: 'absolute', top: '20px', right: '10px', color:'#91c1b4'};

    const styleLblUsersGraphic3 = !isFetchingUserOnline ? {position: 'absolute', top: '-0px', right: '0px', color:'#483d93'}
    : {position: 'absolute', top: '15px', right: '10px', color:'#ccc'};
    
    const winWidth = window.innerWidth;
    let windthLine = 500;
    let leftLine = 30;
    let rightLine = 30;
    if (winWidth < 400){
      windthLine = 250;
      leftLine = 10;
      rightLine = 10;
    }
     
    return (
      <div style={{ position:'relative',overflow: 'hidden'}}>
      <LineChart width={windthLine} height={200} data={data} >
        <CartesianGrid strokeDasharray="8 1" />
        <XAxis dataKey="name" padding={{ left: leftLine, right: rightLine }} />
        <YAxis />
        <Tooltip />
        <Legend  style={{bottom: '10px'}}/>
        <Line type="monotone" dataKey='Users' stroke="#8884d8" activeDot={{ r: 8 }} />
        <Line type="monotone" dataKey="Events" stroke="#82ca9d" />
        <Line type="monotone" dataKey="Close" stroke="#FFc000" />
        
      </LineChart>
      <div style={styleLblUsersGraphic3}>Real Times</div>
      <div style={styleLblUsersGraphic}>Users({usersCount})</div>
      <div style={styleLblUsersGraphic2}>Event({eventsAmount})</div>
      <RefreshIcon id='btnUpdateGraphicUsers' onClick={fetchDataUsersOnline} style={styleBtnUpdateUsersGraphic}/>
      </div>
    );
  } 
}

 
const mapStateToProps = createStructuredSelector ({
  countUsersGraph: selectCountUsersGraph,
  isFetchingUserOnline: selectIsFetchingUserOnline,
  selectAmountEvent: selectAmountEventGraph,
});
 
const mapDispatchToProps = (dispatch) => ({
  fetchDataUsersOnline: () => dispatch(fetchDataUsersOnlineAsync()),
});
export default connect(mapStateToProps, mapDispatchToProps)(LineChartWithXAxisPading);
