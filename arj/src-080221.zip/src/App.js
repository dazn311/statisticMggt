import {
  BrowserRouter as Router,
  Switch,
  Route
} from "react-router-dom";

import './App.css';

import Dashboard from './screens/dashboard';
import AuthDashboard from './screens/auth-dashboard/AuthDashboard';
import UsersDashboard from './screens/users';
import HistoriesDashboard from './screens/historyChanges';
function App() {
  return (
    <div className="App">
      <Router>
        <Switch>
          <Route exact path="/">
            <Dashboard />
          </Route>
          <Route path="/login">
            <AuthDashboard />
          </Route>
          <Route path="/history">
            <HistoriesDashboard />
          </Route>
          <Route path="/users">
            <UsersDashboard />
          </Route>
        </Switch>
      </Router>
    </div>
  );
}

export default App;
